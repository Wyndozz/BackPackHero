package equipment;

import java.util.ArrayList;

import inventory.InventoryCell;
import main.Coordinates;

public class Dart implements Equipment, Weapon{
	private final int damagePoint;
	private final int rarity;
	private final int id;
	private final InventoryCell[][] size;
	private boolean select;
	
	public Dart() {
		damagePoint = 10;
		rarity = 1;
		id = 4;
		size = new InventoryCell[1][1];
		select = false;
	}

	@Override
	public int EquipmentLines() {
		return size.length;
	}
	
	@Override
	public int EquipmentColumns() {
		return size[0].length;
	}
	
	@Override
	public String toString() {
		return "Dart";
	}

	@Override
	public int getId() {
		return id;
	}

	@Override
	public int getEnergy() {
		return 0;
	}

	@Override
	public boolean isSelectable() {
		return true;
	}
	
	@Override
	public int getDamage() {
		return damagePoint;
	}
}
