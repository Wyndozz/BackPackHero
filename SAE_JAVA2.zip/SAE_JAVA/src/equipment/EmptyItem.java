package equipment;

import main.Coordinates;

public class EmptyItem implements Equipment {
	private final int id;
	
	public EmptyItem() {
		id = 0;
	}

	@Override
	public int EquipmentLines() {
		return 0;
	}

	@Override
	public int EquipmentColumns() {
		return 0;
	}

	@Override
	public int getId() {
		return 0;
	}
	
	@Override
	public String toString() {
		return "vide";
	}

	@Override
	public int getEnergy() {
		return 0;
	}

	@Override
	public boolean isSelectable() {
		return false;
	}
}
