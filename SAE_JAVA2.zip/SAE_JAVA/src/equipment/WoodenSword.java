package equipment;

import inventory.InventoryCell;

public class WoodenSword implements Equipment, Weapon {
	private final int damageDealt;
	private final int energyCost;
	private final int rarity;
	private final int id;
	private final InventoryCell[][] size;
	private boolean select;

	public WoodenSword() {
		damageDealt = 7;
		energyCost = 1;
		rarity = 1;
		id = 1;
		size = new InventoryCell[3][1];
		select = false;
	}
	
	@Override
	public int EquipmentLines() {
		return size.length;
	}
	
	@Override
	public int EquipmentColumns() {
		return size[0].length;
	}
	
	@Override
	public String toString() {
		return "WoodenSword";
	}

	@Override
	public int getId() {
		return id;
	}

	@Override
	public int getEnergy() {
		return energyCost;
	}

	@Override
	public boolean isSelectable() {
		return true;
	}

	@Override
	public int getDamage() {
		return damageDealt;
	}
	
}