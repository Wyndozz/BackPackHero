package equipment;

public interface Equipment {

	int EquipmentLines();

	int EquipmentColumns();

	int getId();

//	boolean isSelected();
//	
//	boolean setSelected(Boolean value);	
	
	int getEnergy();
	
	boolean isSelectable();
	
//	boolean isTargetable();
}
