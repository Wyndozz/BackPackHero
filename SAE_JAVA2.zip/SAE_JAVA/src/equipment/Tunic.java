package equipment;

import java.util.ArrayList;

import main.Coordinates;
import inventory.InventoryCell;

public class Tunic implements Equipment, Armor{
	private final int blockPoint;
	private final int rarity;
	private final InventoryCell[][] size;
	private final int id;
	private boolean select;
	
	public Tunic() {
		blockPoint = 5;
		rarity = 1;
		size = new InventoryCell[2][2];
		id = 3;
		select = false;
		
	}

	@Override
	public int EquipmentLines() {
		return size.length;
	}
	
	@Override
	public int EquipmentColumns() {
		return size[0].length;
	}
	
	@Override
	public String toString() {
		return "Tunic";
	}

	@Override
	public int getId() {
		return id;
	}

	@Override
	public int getEnergy() {
		return 0;
	}

	@Override
	public boolean isSelectable() {
		return false;
	}

	@Override
	public int getShield() {
		return blockPoint;
	}

	
}
