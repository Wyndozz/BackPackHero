package room;

public class Healer {
	private final int healAdd;
	private final int maxHealAdd;
	private int healSelected;
	
	public Healer() {
		healAdd = 25;
		maxHealAdd = 5;
		healSelected = -1;
	}
	
	public void healSelected(int healSelected) {
		this.healSelected = healSelected;
	}
	
	public void healAction(Hero hero) {
		if (healSelected == 0) {
			hero.addMaxHP(maxHealAdd);
		}
		else if (healSelected == 1){
			hero.addHP(healAdd);
		}
	}
	
}
