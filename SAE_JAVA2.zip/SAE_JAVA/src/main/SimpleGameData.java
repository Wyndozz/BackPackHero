package main;

import java.awt.image.BufferedImage;
import java.awt.geom.Point2D.Float;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Objects;

import javax.imageio.ImageIO;

import equipment.Equipment;
import inventory.Inventory;
import inventory.InventoryCell;
import room.Healer;
import room.Hero;
import room.Monsters;
import dungeon.Corridors;
import dungeon.DungeonRoom;
import dungeon.EnemyRoom;
import dungeon.FloorGeneration;
import dungeon.MapCell;

public class SimpleGameData {
	private final Inventory inventory;
	private MapCell[][] map;
	private Coordinates heroCoordinates;
	private final Hero hero;
	private final HashMap<Monsters, Integer> monstersAction;
	
	public SimpleGameData(int i, int j, int nbRooms) {
		inventory = new Inventory();
		map = new FloorGeneration(1, nbRooms).floor();
		hero = new Hero();
		monstersAction = new HashMap<>();
	}
	
	public Inventory getInv() {
		return inventory;
	}
	
	public Equipment getEquipment(int i, int j) {
		return inventory.getInventory()[j][i].equipment();
	}
	
	public Point clickOnInventoryCell(int i, int j, SimpleGameView view) {
		
		if (i < 0 || inventoryColumns() <= i || j < 0 || inventoryLines() <= j) {
			return null;
		}
		System.out.println(inventory.getInventory()[j][i] + ": " + i + ", " + j);
		
		float x = view.xFromJ(i);
	    float y = view.yFromI(j);
		return new Point(x, y);
	}
	
	public int inventoryLines() {
		return inventory.getInventory().length;
	}
	
	public int inventoryColumns() {
		return inventory.getInventory()[0].length;
	}
	
	public Point clickOnCell(int i, int j, SimpleGameView view) {
		Objects.requireNonNull(view);
		int id = map[j][i].id();
		if (i < 0 || columns() <= i || j < 0 || lines() <= j || id < 0) {
			throw new IllegalArgumentException("Invalid cell");
		}
		float x = view.xFromJ(i);
	    float y = view.yFromI(j);
		
		return new Point(x, y);
	}
	
	public BufferedImage mapCell(int i, int j) {
		int id = map[i][j].id();
		try {
			switch(id) {
			case 0 : return ImageIO.read(getClass().getResource("/data/map/mapOn.png"));
			case 1 : return ImageIO.read(getClass().getResource("/data/map/exit.png"));
			case 2 : return ImageIO.read(getClass().getResource("/data/map/enemie.png"));
			case 3 : return ImageIO.read(getClass().getResource("/data/map/healer.png"));
			case 4 : return ImageIO.read(getClass().getResource("/data/map/merchant.png"));
			case 5 : return ImageIO.read(getClass().getResource("/data/map/treasure.png"));
		 	case 6 : return ImageIO.read(getClass().getResource("/data/map/start.png"));
			default : return ImageIO.read(getClass().getResource("/data/map/mapOff.png"));
			}
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}
	
	public BufferedImage loadImage(String path) {
	    try {
	        return ImageIO.read(getClass().getResource(path));
	    } catch (IOException e) {
	        throw new RuntimeException("Erreur lors du chargement de l'image : " + path, e);
	    }
	}
	
	public DungeonRoom getRoom(int line, int column) {
		return map[line][column].room();
	}
	
	// Permet de récupérer le point de départ
	public DungeonRoom getStartRoom() {
		for (int i = 0; i < 5; i++) {
			for (int j = 0; j < 11; j++) {
				DungeonRoom room = map[i][j].room();
				if (room.id() == 6) {
					heroCoordinates = new Coordinates(i, j);
					return room;
				}
			}
		}
		return null;
	}
	
	// Détecte si le clique est sur la carte du donjon
	public boolean isOnMap(Float location) {
		Objects.requireNonNull(location);
		return location.x > 1000 && location.x < 1825 && location.y > 50 && location.y < 425;
	}
	
	// Détecte si le clique est sur un des ennemies
	public boolean isOnEnemy(Float location, EnemyRoom room) {
		Objects.requireNonNull(location);
		Objects.requireNonNull(room);
		int xMax = 1000 + room.monsters().size()*300;
		return location.x > 1000 && location.x < xMax && location.y > 650 && location.y < 950;
	}
	
	public boolean isOnHeal(Float location) {
		Objects.requireNonNull(location);
		return ((location.x > 800 && location.x < 900) || (location.x > 1000 && location.x < 1100)) && location.y > 650 && location.y < 750;
	}

	public boolean isOnEquipment(Float location) {
		Objects.requireNonNull(location);
		return location.x > 50 && location.x < 425 && location.y > 50 && location.y < 275;
	}
	
	public boolean isOnEndTurn(Float location) {
		Objects.requireNonNull(location);
		return location.x > 250 && location.x < 450 && location.y > 500 && location.y < 600;
	}
	
	public void monstersNextAction(ArrayList<Monsters> monsters) {
		for (Monsters monster : monsters) {
			int action = monster.getAction();
			if (action == 0)  {
				monster.randomShield();
				monstersAction.put(monster, 0);
			}
			else {
				monster.randomAttack();
				monstersAction.put(monster, 1);
			}
		}
	}
	
	public void selectionMonsters(Monsters monsterSelected, ArrayList<Monsters> monsters) {
		for (Monsters monster : monsters) {
			if (monster.equals(monsterSelected)) {
				monster.select();
			}
			else {
				monster.unselect();
			}
		}
	}
	
	public boolean oneMonsterIsSelected(ArrayList<Monsters> monsters) {
		for (Monsters monster : monsters) {
			if (monster.isSelected()) {
				return true;
			}
		}
		return false;
	}
	
	public void removeRoom(int i, int j) {
		map[i][j] = new MapCell(new Corridors(new Coordinates(i, j)));
	}
	
	public int getAction(Monsters monster) {
		Objects.requireNonNull(monster);
		return monstersAction.get(monster);
	}
	
	public int getActionStat(Monsters monster, int action) {
		Objects.requireNonNull(monster);
		return monster.getActionStat(action);
	}
	
	public void monstersAction(ArrayList<Monsters> monsters) {
		for (Monsters monster : monsters) {
			int action = monstersAction.get(monster);
			if (action == 1) {
				hero.dammageReceived(monster.attack());
			}
		}
	}
	
	public Hero getHero() {
		return hero;
	}
	
	public boolean allMonstersDead(ArrayList<Monsters> monsters) {
		for (Monsters monster : monsters) {
			if (monster.alive()) {
				return false;
			}
		}
		return true;
	}
	
	public void getHealAction(float x, Healer healer) {
		if (x > 800 && x < 900) {
			healer.healSelected(0);
		}
		else {
			healer.healSelected(1);
		}
	}
	
	public void HealAction(Healer healer) {
		healer.healAction(hero);
	}
	
	public Coordinates getHeroCoordinates() {
		return heroCoordinates;
	}
	
	public int lines() {
		return map.length;
	}
	
	public int columns() {
		return map[0].length;
	}
}
