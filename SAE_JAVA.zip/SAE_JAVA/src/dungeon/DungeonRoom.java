package dungeon;

import main.Coordinates;

public interface DungeonRoom {
	Coordinates coordinates();
	
	int id();
	
	String tab();
}
