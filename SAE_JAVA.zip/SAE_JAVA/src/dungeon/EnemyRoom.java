package dungeon;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Objects;
import java.util.concurrent.ThreadLocalRandom;

import main.Coordinates;
import backpackhero.battle.Monsters;
import backpackhero.battle.Ratwolf;
import backpackhero.battle.SmallRatwolf;

public class EnemyRoom implements DungeonRoom {
	private final ArrayList<Monsters> monstersList;
	private final ArrayList<Monsters> monstersInRoom;
	private final Coordinates coordinates;
	private final int id;
	private int nbOfMonsters;
	
	public EnemyRoom(Coordinates coordinates) {
		monstersList = new ArrayList<Monsters>();
		monstersList.add(new Ratwolf(0));
		monstersList.add(new SmallRatwolf(0));
		nbOfMonsters = randomNumberOfMonsters();
		monstersInRoom = monstersGeneration();
		System.out.println(monstersInRoom);
		this.coordinates = coordinates;
		id = 2;
	}
	
	public void add(Monsters monster) {
		Objects.requireNonNull(monster);
		monstersInRoom.add(monster);
	}
	
	public boolean oneAlive() {
		for (var enemy : monstersInRoom) {
			if (enemy.alive()) {
				return true;
			}
		}
		return false;
	}
	
	public boolean removeMonster(Monsters mob) {
		return monstersInRoom.remove(mob);
	}
	
	public ArrayList<Monsters> monsters() {
		return monstersInRoom;
	}
	
	public int randomNumberOfMonsters() {
		return ThreadLocalRandom.current().nextInt(1, 4);
	}
	
	public ArrayList<Monsters> monstersGeneration() {
		ArrayList<Monsters> monstersInRoom = new ArrayList<>();
		HashMap<Integer, Integer> monstersNumber = new HashMap<>();
		for (Monsters monster : monstersList) {
			monstersNumber.put(monster.id(), 0);
		}
		for (int i = 0; i < nbOfMonsters; i++) {
			int randomIndex = ThreadLocalRandom.current().nextInt(0, monstersList.size());
			Monsters randomMonster = monstersList.get(randomIndex);
			int nbMonster = monstersNumber.get(randomMonster.id()) + 1;
			switch(randomMonster.id()) {
				case 1 : 
					monstersNumber.put(1, nbMonster);
					monstersInRoom.add(new SmallRatwolf(nbMonster));
					break;
				case 2 :
					monstersNumber.put(2, nbMonster);
					monstersInRoom.add(new Ratwolf(nbMonster));
					break;
			}
		}
		return monstersInRoom;
	}
	
	public int nbOfMonsters() {
		return nbOfMonsters;
	}
	
	@Override
	public Coordinates coordinates() {
		return coordinates;
	}
	
	@Override
	public int id() {
		return id;
	}
	
	@Override
	public String tab() {
		return "E";
	}
	
	@Override
	public String toString() {
		var string = new StringBuilder();
		for (var monster : monstersInRoom) {
			if (monstersInRoom.indexOf(monster) < monstersInRoom.size()-1) {
				string.append(monster + ", ");
			}
			else {
				string.append(monster);
			}
		}
		return "des ennemies : [" + string + "] ";
	}
}
