package backpackhero.equipment;

public interface Wands {

}
