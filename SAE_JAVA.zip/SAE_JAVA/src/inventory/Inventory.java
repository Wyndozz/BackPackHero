package inventory;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import equipment.EmptyItem;
import equipment.Equipment;
import main.Coordinates;

public class Inventory {
	private final InventoryCell[][] inventory;
	private final HashMap<Coordinates, Equipment> itemMap;
	
	
	public Inventory() {
		inventory = new InventoryCell[3][5];
		itemMap = new HashMap<>();
		inventoryInit();
		putItem(0, 0, new equipment.WoodenSword());
		putItem(0, 1, new equipment.RoughBuckler());
		putItem(0, 3, new equipment.Tunic());
	}
	
	private void inventoryInit() {
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 5; j++) {
				inventory[i][j] = new InventoryCell(new EmptyItem());
			}
		}
	}
	
	public InventoryCell[][] getInventory() {
		return inventory;
	}
	
	public HashMap<Coordinates, Equipment> getMap() {
		return itemMap;
	}
	
	public void putItem(int ipos, int jpos, Equipment equipment) {
		itemMap.put(new Coordinates(ipos, jpos), equipment);
		for (int i = 0; i < equipment.EquipmentLines(); i++) {
			for (int j = 0; j < equipment.EquipmentColumns(); j++) {
				inventory[i+ipos][j+jpos] = new InventoryCell(equipment);
			}
		}
	}
	
	public void removeItem(Equipment equipment) {
		itemMap.forEach((key, value) -> {
			if (value.equals(equipment)) {
				int ipos = key.i();
				int jpos = key.j();
				itemMap.remove(key);
				for (int i = 0; i < equipment.EquipmentLines(); i++) {
					for (int j = 0; j < equipment.EquipmentColumns(); j++) {
						inventory[i+ipos][j+jpos] = new InventoryCell(new EmptyItem());
					}
				}
			}
		});
	}
}
