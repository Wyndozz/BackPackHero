package inventory;

public class InventoryCell {
	private final int id;
	private boolean empty;
	
	public InventoryCell(int i) {
		id = i;
		empty = true;
	}
}
