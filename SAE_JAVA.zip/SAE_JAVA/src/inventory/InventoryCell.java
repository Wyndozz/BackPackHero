package inventory;

import equipment.Equipment;
import equipment.WoodenSword;

/**
 * La classe InventoryCell représente une cellule d'inventaire qui peut contenir un équipement.
 */
public class InventoryCell {
    private final int empty;
    private final Equipment equipment;

    /**
     * Constructeur de la classe InventoryCell.
     *
     * @param equipment l'équipement à stocker dans la cellule d'inventaire
     */
    public InventoryCell(Equipment equipment) {
        empty = 0;
        this.equipment = equipment;
    }

    /**
     * Retourne l'équipement contenu dans la cellule d'inventaire.
     *
     * @return l'équipement contenu dans la cellule d'inventaire
     */
    public Equipment equipment() {
        return equipment;
    }
    
    @Override
    public String toString() {
    	return equipment.toString() + "";
    }

}
