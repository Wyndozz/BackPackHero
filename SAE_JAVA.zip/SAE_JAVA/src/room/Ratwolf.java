package room;

import java.util.concurrent.ThreadLocalRandom;

public class Ratwolf implements Monsters {
	private int healthPoint;
	private int shieldPoint;
	private int attackPoint;
	private final int number;
	private final int id;
	private final int xp;
	private final int minAttack;
	private final int maxAttack;
	private final int minShield;
	private final int maxShield;

	public Ratwolf(int number) {
		minAttack = 7;
		maxAttack = 9;
		minShield = 13;
		maxShield = 16;
		healthPoint = 45;
		this.number = number;
		id = 2;
		xp = 6;
	}
	
	@Override
	public int number() {
		return number;
	}
	
	@Override
	public int id() {
		return id;
	}
	
	@Override
	public void randomAttack() {
		attackPoint = (int) ThreadLocalRandom.current().nextInt(minAttack, maxAttack+1);
	}
	
	@Override
	public void randomShield() {
		shieldPoint = (int) ThreadLocalRandom.current().nextInt(minShield, maxShield+1);
	}

	@Override
	public int attack() {
		shieldPoint = 0;
		return attackPoint;
	}

	@Override
	public int shield() {
		attackPoint = 0;
		return shieldPoint;
	}

	@Override
	public void dammageReceived(int dammage) {
		int remainingShield = shieldPoint - dammage;
		if (remainingShield < 0) {
			shieldPoint = 0;
			healthPoint += remainingShield;
		} else {
			shieldPoint -= dammage;
		}
		if (healthPoint < 0) {
			healthPoint = 0;
		}
	}

	@Override
	public String toString() {
		return "Ratwolf";
	}
	
	@Override
	public int getHP() {
		return healthPoint;
	}
}
