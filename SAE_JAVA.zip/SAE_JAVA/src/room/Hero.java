package room;

import java.util.ArrayList;
import java.util.Objects;
import java.util.Scanner;

import equipment.Armor;
import equipment.Equipment;
import equipment.Weapon;

public class Hero {
	private int maxHealPoint;
	private int healPoint;
	private int attackPoint;
	private int shieldPoint;
	private final int maxEnergy;
	private int energy;
	private final ArrayList<Equipment> equipment;

	public Hero() {
		maxHealPoint = 40;
		maxEnergy = 3;
		healPoint = 40;
		attackPoint = 0;
		shieldPoint = 0;
		energy = 3;
		equipment = new ArrayList<>();
	}
	
	public boolean canActionEnergy(int e) {
		return energy >= e;
	}
	
	public boolean removeEnergy(int e) {
		if (canActionEnergy(e)) {
			energy -= e;
			return true;
		}
		return false;
	}

	public void dammageReceived(int dammage) {
		int remainingShield = shieldPoint - dammage;
		if (remainingShield < 0) {
			shieldPoint = 0;
			healPoint += remainingShield;
		} else {
			shieldPoint -= dammage;
		}
		if (healPoint < 0) {
			healPoint = 0;
		}
	}
	
	public void addHP(int heal) {
		if (healPoint + heal > maxHealPoint) {
			healPoint = maxHealPoint;
		}
		else {
			healPoint += heal;
		}
	}
	
	public void addMaxHP(int hp) {
		maxHealPoint += hp;
	}
	
	public void addShield(int shield) {
		shieldPoint += shield;
	}
	
	public ArrayList<Equipment> getEquipment() {
		return equipment;
	}
	
	public Equipment getItem(int id) {
		for (var item : equipment) {
			if (item.getId() == id) {
				return item;
			}
		}
		return null;
	}

	public void endTurn() {
		shieldPoint = 0;
		energy = 3;
	}

	public boolean alive() {
		return healPoint > 0;
	}

	public void addEquipment(Equipment e) {
		Objects.requireNonNull(e);
		equipment.add(e);
	}

	public boolean removeEquipment(Equipment e) {
		Objects.requireNonNull(e);
		return equipment.remove(e);
	}
	
	public int getMaxHP() {
		return maxHealPoint;
	}

	public int getHP() {
		return healPoint;
	}
	
	public int getMaxEnergy() {
		return maxEnergy;
	}

	public int getEnergy() {
		return energy;
	}
}
