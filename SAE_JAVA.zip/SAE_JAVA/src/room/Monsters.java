package room;

import java.util.concurrent.ThreadLocalRandom;

public interface Monsters {
	
	default int getAction() {
		return (int) ThreadLocalRandom.current().nextInt(0, 2);
	}
	
	default int getActionStat(int action) {
		if (action == 0) {
			int stat = shield();
			return stat;
		}
		else {
			int stat = attack();
			return stat;
		}
	}

	default int getFutureAttack() {
		System.out.println(this + "va vous attaquer avec " + attack() + " points de dégâts");
		return attack();
	}

	default int getFutureShield() {
		System.out.println(this + "s'ajoute " + attack() + " points de bouclier");
		return shield();
	}
	
	default boolean alive() {
		return getHP() > 0;
	}
	
	int number();
	
	int id();
	
	void randomAttack();
	
	void randomShield();

	int attack();
	int shield();

	void dammageReceived(int dammage);
	
	int getHP();
}
