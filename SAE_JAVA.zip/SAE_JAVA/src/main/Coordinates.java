package main;

public record Coordinates(int i, int j) {
	
}
