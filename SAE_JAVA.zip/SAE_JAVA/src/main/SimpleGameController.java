package main;

import java.awt.Color;
import java.util.ArrayList;

import dungeon.EnemyRoom;
import dungeon.DungeonRoom;
import fr.umlv.zen5.Application;
import fr.umlv.zen5.ApplicationContext;
import fr.umlv.zen5.KeyboardKey;
import fr.umlv.zen5.Event.Action;
import room.Healer;
import room.Hero;
import room.Monsters;

public class SimpleGameController {
//	public SimpleGameController() {
//	
//	}
	
	/* Lancement dès l'entrée dans une salle contenant des ennemies */
	private static boolean battleLoop(ApplicationContext context, SimpleGameData data, SimpleGameView view, EnemyRoom room, Point point) {
		ArrayList<Monsters> monsters = ((EnemyRoom) room).monsters();
		var event = context.pollOrWaitEvent(10);
		if (event == null) {
			return true;
		}
		if (data.getHero().getHP() == 0 || data.allMonstersDead(monsters)) {
			return false;
		}
		var action = event.getAction();
		if (action == Action.POINTER_DOWN) {
			var location = event.getLocation();
			if (data.isOnEnemy(location, room)) {
				Point monsterSelectedOrigin = view.getMonsterSelected(location.x, location.y, room);
				SimpleGameView.drawBattle(context, data, view, point, monsters);
				SimpleGameView.drawMonsterSelection(context, data, view, monsterSelectedOrigin);
				Monsters monsterSelected = view.getMonster(location.x, location.y, room);
				data.selectionMonsters(monsterSelected, monsters);
			}
			else if (data.isOnEquipment(location) && data.oneMonsterIsSelected(monsters)) {
				
				SimpleGameView.drawBattle(context, data, view, point, monsters);
			}
			else if (data.isOnEndTurn(location)) {
				data.monstersAction(monsters);
				data.monstersNextAction(monsters);
				SimpleGameView.drawBattle(context, data, view, point, monsters);
			}
		}
		else if(action == Action.KEY_PRESSED && event.getKey() == KeyboardKey.Q) {
			return false;
		}
		return true;
	}
	
	private static Coordinates healerLoop(ApplicationContext context, SimpleGameData data, SimpleGameView view, Point point, Healer healer) {
		var event = context.pollOrWaitEvent(10);
		if (event == null) {
			return null;
		}
		var action = event.getAction();
		if (action == Action.POINTER_DOWN) {
			var location = event.getLocation();
			if (data.isOnHeal(location)) {
				SimpleGameView.draw(context, data, view, point);
				SimpleGameView.drawHealer(context, data, view);
				Point healSelectedOrigin = view.getHealSelected(location.x, location.y);
				SimpleGameView.drawHealSelection(context, data, view, healSelectedOrigin);
				data.getHealAction(location.x, healer);
			}
			else if (data.isOnMap(location)) {
				int column = view.columnFromX(location.x);
				int line = view.lineFromY(location.y);
				DungeonRoom room =  data.getRoom(line, column);
				if (room.id() >= 0) {
					data.HealAction(healer);
					return new Coordinates(column, line);
				}
			}
		}
		return null;
	}
	
	/* Lancement du jeu */
	private static void gameStart(ApplicationContext context) {
		int xOriginMap = 1000;
		int yOriginMap = 50;
		int nbRooms = 25;
		
		SimpleGameData data = new SimpleGameData(5, 11, nbRooms);
		SimpleGameView view = SimpleGameView.initGameGraphics(xOriginMap, yOriginMap, 825, 375, 75, 0, data);
		SimpleGameView.draw(context, data, view, new Point(view.xFromJ(data.getStartRoom().coordinates().j()), view.yFromI(data.getStartRoom().coordinates().i())));
		Hero hero = new Hero();
		while (true) {
			var event = context.pollOrWaitEvent(10);
			if (event != null) {
				var action = event.getAction();
				if (action == Action.KEY_PRESSED && event.getKey() == KeyboardKey.Q) {
					context.exit(0);
				}
				if (action == Action.POINTER_DOWN) {
					var location = event.getLocation();
					if (data.isOnMap(location)) { // Si on clique sur la carte
						Coordinates heroCoordinates = data.getHeroCoordinates();
						int column = view.columnFromX(location.x);
						int line = view.lineFromY(location.y);
						DungeonRoom room = data.getRoom(line, column);
						if (room.id() >= 0) { // S'il ne s'agit pas d'une pièce inaccessible
							Point pt1 = data.clickOnCell(column, line, view);
							SimpleGameView.draw(context, data, view, pt1);
							if (room.id() == 2) { // Si la pièce est rempli d'ennemies
								//Lancement du combat
								ArrayList<Monsters> monsters = ((EnemyRoom) room).monsters();
								data.monstersNextAction(monsters);
								SimpleGameView.drawEnemies(context, data, view, monsters);
								SimpleGameView.drawMonstersAction(context, data, view, monsters);
								while (true) {
									if (!battleLoop(context, data, view, (EnemyRoom) room, pt1)) {
										SimpleGameView.draw(context, data, view, pt1);
										break;
									}
								}
								if (data.getHero().getHP() == 0) {
									System.out.println("Vous avez perdu !");
									context.exit(0);
								}
							}
							else if (room.id() == 3) { // Si la pièce est une pièce de soin
								// Lancement des interactions avec le soigneur
								SimpleGameView.drawHealer(context, data, view);
								Healer healer = new Healer();
								while (true) {
									Coordinates coord = healerLoop(context, data, view, pt1, healer);
									if (coord != null) {
										data.removeRoom(line, column);
										Point pt2 = data.clickOnCell(coord.i(), coord.j(), view);
										SimpleGameView.draw(context, data, view, pt2);
										break;
									}
								}
							}
						}
					}
					
				}
			}
		}
		
	}
	
	public static void main(String[] args) {
		Application.run(new Color(185, 122, 87), SimpleGameController::gameStart);
	}
}
