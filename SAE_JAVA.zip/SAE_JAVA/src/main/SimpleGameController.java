package main;

import java.awt.Color;

import backpackhero.battle.Monsters;
import dungeon.EnemyRoom;
import dungeon.DungeonRoom;
import fr.umlv.zen5.Application;
import fr.umlv.zen5.ApplicationContext;
import fr.umlv.zen5.KeyboardKey;
import fr.umlv.zen5.Event.Action;

public class SimpleGameController {
	
//	public SimpleGameController() {
//	
//	}
	
	/* Lancement dès l'entrée dans une salle contenant des ennemies */
	private static boolean battleLoop(ApplicationContext context, SimpleGameData data, SimpleGameView view, EnemyRoom room, Point point) {
		var event = context.pollOrWaitEvent(10);
		if (event == null) {
			return true;
		}
		var action = event.getAction();
		if (action == Action.POINTER_DOWN) {
			var location = event.getLocation();
			if (data.isOnEnemy(location, room)) {	
				SimpleGameView.draw(context, data, view, point);
				SimpleGameView.drawEnemies(context, data, view, ((EnemyRoom) room).monsters());
				SimpleGameView.drawBattle(context, data, view, ((EnemyRoom) room).monsters());
				Point monsterSelectedOrigin = view.getMonsterSelected(location.x, location.y, room);
				SimpleGameView.drawMonsterSelection(context, data, view, monsterSelectedOrigin);
				Monsters monsterSelected = view.getMonster(location.x, location.y, room);
			}
			if (data.isOnMap(location)) {
				return false;
			}
		}
		return true;
	}
	
	/* Lancement du jeu */
	private static void gameStart(ApplicationContext context) {
		int xOriginMap = 1000;
		int yOriginMap = 50;
		int nbRooms = 15;
		
		SimpleGameData data = new SimpleGameData(5, 11, nbRooms);
		SimpleGameView view = SimpleGameView.initGameGraphics(xOriginMap, yOriginMap, 825, 375, 75, 0, data);
		SimpleGameView.draw(context, data, view, new Point(view.xFromJ(data.getStartRoom().coordinates().j()), view.yFromI(data.getStartRoom().coordinates().i())));
		
		while (true) {
			var event = context.pollOrWaitEvent(10);
			if (event != null) {
				var action = event.getAction();
				if (action == Action.KEY_PRESSED && event.getKey() == KeyboardKey.Q) {
					context.exit(0);
				}
				if (action == Action.POINTER_DOWN) {
					var location = event.getLocation();
					if (data.isOnMap(location)) {
						int column = view.columnFromX(location.x);
						int line = view.lineFromY(location.y);
						DungeonRoom room = data.getRoom(line, column);
						if (room.id() >= 0) {
							Point pt1 = data.clickOnCell(column, line, view);
							SimpleGameView.draw(context, data, view, pt1);
							if (room.id() == 2) {
								int i = 0;
								SimpleGameView.drawEnemies(context, data, view, ((EnemyRoom) room).monsters());
								SimpleGameView.drawBattle(context, data, view, ((EnemyRoom) room).monsters());
								while (true) {
									if (!battleLoop(context, data, view, (EnemyRoom) room, pt1)) {
										SimpleGameView.draw(context, data, view, pt1);
										break;
									}
								}
							}
						}
					}
					
				}
			}
		}
		
	}
	
	public static void main(String[] args) {
		Application.run(new Color(185, 122, 87), SimpleGameController::gameStart);
	}
}
