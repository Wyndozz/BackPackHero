package main;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.Objects;

import dungeon.EnemyRoom;
import fr.umlv.zen5.ApplicationContext;
import room.Monsters;

public record SimpleGameView(int xOriginMap, int yOriginMap, int width, int height, int cellSize, int cellMargin) {
	
	public static SimpleGameView initGameGraphics(int xOriginMap, int yOriginMap, int width, int height, int cellSize, int cellMargin, SimpleGameData data) {
		Objects.requireNonNull(data);
		return new SimpleGameView(xOriginMap, yOriginMap, width, height, cellSize, cellMargin);
	}
	
	public float xFromJ(int j) {
		return xOriginMap + j * cellSize + cellMargin*(j+1);
	}
	
	public float yFromI(int i) {
		return yOriginMap + i * cellSize + cellMargin*(i+1);
	}
	
	private static void checkRange(double min, double value, double max) {	
		if (value < min || value > max) {
			throw new IllegalArgumentException("Invalid coordinate: " + value);
		}
	}
	
	private int indexFromRealCoord(float coord, int origin) {
		return (int) ((coord - origin) / cellSize);
	}
	
	public int lineFromY(float y) {
		checkRange(yOriginMap, y, yOriginMap + height);
		return indexFromRealCoord(y, yOriginMap);
	}
	
	public int columnFromX(float x) {
		checkRange(xOriginMap, x, xOriginMap + width);
		return indexFromRealCoord(x, xOriginMap);
	}
	
	public Monsters getMonster(float x, float y, EnemyRoom room) {
		checkRange(1000, x, 1900);
		checkRange(650, y, 950);
		if (x < 1300) {
			return room.monsters().get(0);
		}
		else if (x < 1600) {
			return room.monsters().get(1);
		}
		else {
			return room.monsters().get(2);
		}
	}
	
	public Point getMonsterSelected(float x, float y, EnemyRoom room) {
		checkRange(1000, x, 1900);
		checkRange(650, y, 950);
		if (x < 1300) {
			return new Point(1000, 650);
		}
		else if (x < 1600) {
			return new Point(1300, 650);
		}
		else {
			return new Point(1600, 650);
		}
		
	}
	
	public Point getHealSelected(float x, float y) {
		checkRange(800, x, 1100);
		checkRange(650, y, 750);
		if (x < 900) {
			return new Point(800, 650);
		}
		else {
			return new Point(1000, 650);
		}
		
	}
	
//	private void drawCell(Graphics2D graphics, SimpleGameData data, int i, int j, Color color) {
//		var x = xFromJ(j);
//		var y = yFromI(i);
//		graphics.setColor(color);
//		graphics.fill(new Rectangle2D.Float(x, y, cellSize, cellSize));
//	}
	
	public void drawFont(Graphics2D graphics, Color color, int fontSize, String string, float x, float y) {
		graphics.setColor(color);
		Font font = new Font("Noto Sans", Font.BOLD, fontSize);
		graphics.setFont(font);
		graphics.drawString(string, x, y);
	}
	
	public void drawImage(Graphics2D graphics, float x, float y, float dimX, float dimY, BufferedImage image) {
		var width = image.getWidth();
		var height = image.getHeight();
		var scale = Math.min(dimX / width, dimY / height);
		var transform = new AffineTransform(scale, 0, 0, scale, x + (dimX - scale * width) / 2,
				y + (dimY - scale * height) / 2);
		graphics.drawImage(image, transform, null);
	}
	
	private void drawHealSelection(Graphics2D graphics, SimpleGameData data, Point point) {
		graphics.setColor(Color.RED);
		graphics.draw(new Rectangle2D.Float(point.x(), point.y(), 100, 100));
	}
	
	public static void drawHealSelection(ApplicationContext context, SimpleGameData data, SimpleGameView view, Point point) {
		context.renderFrame(graphics -> view.drawHealSelection(graphics, data, point));
	}
	
	public void drawHealer(Graphics2D graphics, SimpleGameData data) {
		drawImage(graphics, 1300, 650, 300, 300, data.healer());
		drawImage(graphics, 800, 650, 100, 100, data.hp());
		drawImage(graphics, 1000, 650, 100, 100, data.hp());
		drawFont(graphics, Color.RED, 30, "+5 HP Max", 775, 600);
		drawFont(graphics, Color.RED, 30, "+25 HP", 1000, 600);
	}
	
	public static void drawHealer(ApplicationContext context, SimpleGameData data, SimpleGameView view) {
		context.renderFrame(graphics -> view.drawHealer(graphics, data));
	}
	
	public void drawMonstersAction(Graphics2D graphics, SimpleGameData data, ArrayList<Monsters> monsters) {
		int i = 0;
		for (Monsters monster : monsters) {
			if (data.getAction(monster) == 0) {
				drawImage(graphics, 1225+i*300, 650, 75, 75, data.monsterShield());
				drawFont(graphics, Color.WHITE, 25, data.getActionStat(monster, 0) + "", 1245+i*300, 695);
			}
			else {
				drawImage(graphics, 1225+i*300, 650, 75, 75, data.monsterAttack());
				drawFont(graphics, Color.WHITE, 25, data.getActionStat(monster, 1) + "", 1245+i*300, 693);
			}
			i++;
		}
	}
	
	public static void drawMonstersAction(ApplicationContext context, SimpleGameData data, SimpleGameView view, ArrayList<Monsters> monsters) {
		context.renderFrame(graphics -> view.drawMonstersAction(graphics, data, monsters));
	}
	
	private void drawMonsterSelection(Graphics2D graphics, SimpleGameData data, Point point) {
		graphics.setColor(Color.RED);
		graphics.draw(new Rectangle2D.Float(point.x(), point.y(), 300, 300));
	}
	
	public static void drawMonsterSelection(ApplicationContext context, SimpleGameData data, SimpleGameView view, Point point) {
		context.renderFrame(graphics -> view.drawMonsterSelection(graphics, data, point));
	}
	
	private void drawEnemies(Graphics2D graphics, SimpleGameData data, ArrayList<Monsters> monsters) {
		int i = 0;
		for (Monsters monster : monsters) {
			drawImage(graphics, 1000+i*300, 650, 300, 300, data.enemy(monster.toString()));
			drawImage(graphics, 1000+i*300, 650, 75, 75, data.hp());
			drawFont(graphics, Color.WHITE, 25, monster.getHP() + "", 1025+i*300, 693);
			i++;
		}
	}
	
	public static void drawEnemies(ApplicationContext context, SimpleGameData data, SimpleGameView view, ArrayList<Monsters> monsters) {
		context.renderFrame(graphics -> view.drawEnemies(graphics, data, monsters));
	}
	
	private void draw(Graphics2D graphics, SimpleGameData data, Point point) {
		graphics.setColor(new Color(56, 35, 7));
		graphics.fill(new Rectangle2D.Float(xOriginMap, yOriginMap, width, height));
		
		/* Affichage des images */
		drawImage(graphics, 0, 0, 1920, 1080, data.background()); // Arrière plan
		drawImage(graphics, 200, 650, 300, 300, data.character()); // Personnage
		drawImage(graphics, 200, 650, 75, 75, data.hp()); // Logo point de vie
		drawImage(graphics, 425, 650, 75, 75, data.energy()); // Logo énergie
		
		drawFont(graphics, Color.WHITE, 25, data.getHero().getHP() + "/" + data.getHero().getMaxHP(), 205, 693);
		drawFont(graphics, Color.WHITE, 25, data.getHero().getEnergy() + "/" + data.getHero().getMaxEnergy(), 444, 698);
		
		for (int i = 0; i < data.lines(); i++) {
			for (int j = 0; j < data.columns(); j++) {
				drawImage(graphics, xFromJ(j), yFromI(i), 75, 75, data.mapCell(i, j)); // Cellules de la carte
			}
		}
		
		drawImage(graphics, point.x(), point.y(), 75, 75, data.heroIcon()); // Icone du personnage sur la carte
	}
	
	public static void draw(ApplicationContext context, SimpleGameData data, SimpleGameView view, Point point) {
		context.renderFrame(graphics -> view.draw(graphics, data, point));
	}
}
