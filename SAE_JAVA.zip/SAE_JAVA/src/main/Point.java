package main;

public record Point(float x, float y) {
	
}
