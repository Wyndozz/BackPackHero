package main;

import java.awt.image.BufferedImage;
import java.awt.geom.Point2D.Float;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;

import equipment.Equipment;
import inventory.InventoryCell;
import dungeon.DungeonRoom;
import dungeon.EnemyRoom;
import dungeon.FloorGeneration;
import dungeon.MapCell;

public class SimpleGameData {
	private final InventoryCell[][] inventory;
	private MapCell[][] map;
	private final ArrayList<Equipment> equipment;
	
	public SimpleGameData(int i, int j, int nbRooms) {
		inventory = new InventoryCell[3][5];
		equipment = new ArrayList<>();
		map = new FloorGeneration(1, nbRooms).floor();
	}
	
	public Point clickOnCell(int i, int j, SimpleGameView view) {
		int id = map[j][i].id();
		if (i < 0 || columns() <= i || j < 0 || lines() <= j || id < 0) {
			throw new IllegalArgumentException("Invalid cell");
		}
		float x = view.xFromJ(i);
	    float y = view.yFromI(j);
		
		return new Point(x, y);
	}
	
	public BufferedImage mapCell(int i, int j) {
		int id = map[i][j].id();
		try {
			switch(id) {
			case 0 : return ImageIO.read(getClass().getResource("/img/mapOn.png"));
			case 1 : return ImageIO.read(getClass().getResource("/img/exit.png"));
			case 2 : return ImageIO.read(getClass().getResource("/img/enemie.png"));
			case 3 : return ImageIO.read(getClass().getResource("/img/healer.png"));
			case 4 : return ImageIO.read(getClass().getResource("/img/merchant.png"));
			case 5 : return ImageIO.read(getClass().getResource("/img/treasure.png"));
		 	case 6 : return ImageIO.read(getClass().getResource("/img/start.png"));
			default : return ImageIO.read(getClass().getResource("/img/mapOff.png"));
			}
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}
	
	public BufferedImage background() {
		try {
			return ImageIO.read(getClass().getResource("/img/background.png"));
		} catch(IOException e) {
			throw new RuntimeException(e);
		}
	}
	
	public BufferedImage character() {
		try {
			return ImageIO.read(getClass().getResource("/img/hero.gif"));
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}
	
	public BufferedImage heroIcon() {
		try {
			return ImageIO.read(new File("src/img/heroIcon.png"));
		} catch (IOException e) {
		    throw new RuntimeException(e);
		}
	}

	public BufferedImage enemy(String monster) {
		try {
			return ImageIO.read(getClass().getResource("/img/" + monster + ".png"));
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}
	
	public BufferedImage hp() {
		try {
			return ImageIO.read(getClass().getResource("/img/hp.png"));
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}
	
	public BufferedImage energy() {
		try {
			return ImageIO.read(getClass().getResource("/img/energy.png"));
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}
	
	public DungeonRoom getRoom(int line, int column) {
		return map[line][column].room();
	}
	
	// Permet de récupérer le point de départ
	public DungeonRoom getStartRoom() {
		for (int i = 0; i < 5; i++) {
			for (int j = 0; j < 11; j++) {
				DungeonRoom room = map[i][j].room();
				if (room.id() == 6) {
					return room;
				}
			}
		}
		return null;
	}
	
	// Détecte si le clique est sur la carte du donjon
	public boolean isOnMap(Float location) {
		return location.x > 1000 && location.x < 1825 && location.y > 50 && location.y < 425;
	}
	
	// Détecte si le clique est sur un des ennemies
	public boolean isOnEnemy(Float location, EnemyRoom room) {
		int xMax = 1000 + room.monsters().size()*300;
		return location.x > 1000 && location.x < xMax && location.y > 600 && location.y < 900;
	}
	
	public int lines() {
		return map.length;
	}
	
	public int columns() {
		return map[0].length;
	}
}
