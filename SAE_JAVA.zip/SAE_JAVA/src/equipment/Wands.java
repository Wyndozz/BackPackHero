package equipment;

public interface Wands {

}
