package equipment;

public interface Armor {
	
	int getShield();

}
