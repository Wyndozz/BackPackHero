package equipment;

import inventory.InventoryCell;

public interface Equipment {

	int EquipmentLines();

	int EquipmentColumns();

	int getId();

//	boolean isSelected();
//	
//	boolean setSelected(Boolean value);	
	
	int getEnergy();
	
	InventoryCell[][] getSize();
	
	boolean isSelectable();
	
//	boolean isTargetable();
}
