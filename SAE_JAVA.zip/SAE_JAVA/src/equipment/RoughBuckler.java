package equipment;

import java.util.ArrayList;

import main.Coordinates;
import inventory.InventoryCell;

public class RoughBuckler implements Equipment, Armor{
	private final int blockPoint;
	private final int energyCost;
	private final int rarity;
	private final int id;
	private final InventoryCell[][] size;
	private boolean select;
	
	public RoughBuckler() {
		blockPoint = 7;
		energyCost = 1;
		rarity = 1;
		size = new InventoryCell[2][2];
		id = 10;
		select = false;
	}

	@Override
	public int EquipmentLines() {
		return size.length;
	}
	
	@Override
	public int EquipmentColumns() {
		return size[0].length;
	}
	
	@Override
	public String toString() {
		return "RoughBuckler";
	}

	@Override
	public int getId() {
		return id;
	}

	@Override
	public int getEnergy() {
		return energyCost;
	}

	@Override
	public boolean isSelectable() {
		return true;
	}

	@Override
	public int getShield() {
		return blockPoint;
	}

	@Override
	public InventoryCell[][] getSize() {
		return size;
	}
}
