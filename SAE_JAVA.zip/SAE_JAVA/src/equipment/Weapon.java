package equipment;

public interface Weapon {
	
	int getDamage();

}
