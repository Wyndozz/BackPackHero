package main;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;

import equipment.Equipment;
import inventory.InventoryCell;
import dungeon.FloorGeneration;
import dungeon.InaccessibleRoom;
import dungeon.MapCell;

public class SimpleGameData {
	private final InventoryCell[][] inventory;
	private MapCell[][] map;
	private final ArrayList<Equipment> equipment;
	
	public SimpleGameData(int i, int j, int nbRooms) {
		inventory = new InventoryCell[3][5];
		equipment = new ArrayList<>();
		map = new FloorGeneration(1, nbRooms).floor();
	}
	
//	public Color colorCell(int i, int j) {
//		int id = map[i][j].id();
//		switch(id) {
//			case 0 : return new Color(238, 211, 185);
//			case 1 : return Color.GREEN;
//			case 2 : return Color.RED;
//			case 3 : return Color.YELLOW;
//			case 4 : return Color.BLUE;
//			case 5 : return Color.orange;
//		 	case 6 : return Color.white;
//			default : return Color.BLACK;
//		}
//	}
	
	public Point clickOnCell(int i, int j, SimpleGameView view) {
		int id = map[j][i].id();
		if (i < 0 || columns() <= i || j < 0 || lines() <= j || id < 0) {
			throw new IllegalArgumentException("Invalid cell");
		}
		
		float x = view.xFromJ(i);
	    float y = view.yFromI(j);
		
		return new Point(x, y);
	}
	
	public BufferedImage mapCell(int i, int j) {
		int id = map[i][j].id();
		try {
			switch(id) {
			case 0 : return ImageIO.read(getClass().getResource("/img/mapOn.png"));
			case 1 : return ImageIO.read(getClass().getResource("/img/exit.png"));
			case 2 : return ImageIO.read(getClass().getResource("/img/enemie.png"));
			case 3 : return ImageIO.read(getClass().getResource("/img/healer.png"));
			case 4 : return ImageIO.read(getClass().getResource("/img/merchant.png"));
			case 5 : return ImageIO.read(getClass().getResource("/img/treasure.png"));
		 	case 6 : return ImageIO.read(getClass().getResource("/img/start.png"));
			default : return ImageIO.read(getClass().getResource("/img/mapOff.png"));
			}
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}
	
	public BufferedImage character() {
		try {
			return ImageIO.read(getClass().getResource("/img/hero.gif"));
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}
	
	public int lines() {
		return map.length;
	}
	
	public int columns() {
		return map[0].length;
	}
}
