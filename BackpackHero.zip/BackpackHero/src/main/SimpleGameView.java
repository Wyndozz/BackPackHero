package main;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.util.Objects;

import javax.imageio.ImageIO;

import fr.umlv.zen5.ApplicationContext;

public record SimpleGameView(int xOrigin, int yOrigin, int width, int height, int cellSize, int cellMargin) {
	/*50, 50, 825/11, 375/5*/
	
	public static SimpleGameView initGameGraphics(int xOrigin, int yOrigin, int width, int height, int cellSize, int cellMargin, SimpleGameData data) {
		Objects.requireNonNull(data);
		return new SimpleGameView(xOrigin, yOrigin, width, height, cellSize, cellMargin);
	}
	
	public float xFromJ(int j) {
		return xOrigin + j * cellSize + cellMargin*(j+1);
	}
	
	public float yFromI(int i) {
		return yOrigin + i * cellSize + cellMargin*(i+1);
	}
	
	private static void checkRange(double min, double value, double max) {	
		if (value < min || value > max) {
			throw new IllegalArgumentException("Invalid coordinate: " + value);
		}
	}
	
	private int indexFromRealCoord(float coord, int origin) {
		return (int) ((coord - origin) / cellSize);
	}
	
	public int lineFromY(float y) {
		checkRange(yOrigin, y, yOrigin + height);
		return indexFromRealCoord(y, yOrigin);
	}
	
	public int columnFromX(float x) {
		checkRange(xOrigin, x, xOrigin + width);
		return indexFromRealCoord(x, xOrigin);
	}
	
//	private void drawCell(Graphics2D graphics, SimpleGameData data, int i, int j, Color color) {
//		var x = xFromJ(j);
//		var y = yFromI(i);
//		graphics.setColor(color);
//		graphics.fill(new Rectangle2D.Float(x, y, cellSize, cellSize));
//	}
	
	public void drawImage(Graphics2D graphics, float x, float y, float dimX, float dimY, BufferedImage image) {
		var width = image.getWidth();
		var height = image.getHeight();
		var scale = Math.min(dimX / width, dimY / height);
		var transform = new AffineTransform(scale, 0, 0, scale, x + (dimX - scale * width) / 2,
				y + (dimY - scale * height) / 2);
		graphics.drawImage(image, transform, null);
	}
	
	private void draw(Graphics2D graphics, SimpleGameData data) {
		graphics.setColor(new Color(56, 35, 7));
		graphics.fill(new Rectangle2D.Float(xOrigin, yOrigin, width, height));
		
		drawImage(graphics, 200, 600, 300, 300, data.character());
		
		for (int i = 0; i < data.lines(); i++) {
			for (int j = 0; j < data.columns(); j++) {
				drawImage(graphics, xFromJ(j), yFromI(i), 75, 75, data.mapCell(i, j));
			}
		}
	}
	
	public static void draw(ApplicationContext context, SimpleGameData data, SimpleGameView view) {
		context.renderFrame(graphics -> view.draw(graphics, data));
	}
}
