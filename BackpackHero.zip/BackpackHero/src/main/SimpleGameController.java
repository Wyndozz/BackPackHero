package main;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import fr.umlv.zen5.Application;
import fr.umlv.zen5.ApplicationContext;
import fr.umlv.zen5.Event;
import fr.umlv.zen5.KeyboardKey;
import fr.umlv.zen5.Event.Action;

public class SimpleGameController {
	
//	public SimpleGameController() {
//	
//	}
	
	private static void mapGenerator(ApplicationContext context) {
		int xOrigin = 1000;
		int yOrigin = 50;
		int nbRooms = 15;
		
		SimpleGameData data = new SimpleGameData(5, 11, nbRooms);
		SimpleGameView view = SimpleGameView.initGameGraphics(xOrigin, yOrigin, 825, 375, 75, 0, data);
		SimpleGameView.draw(context, data, view);
		
		BufferedImage image;
		
		try {
			image = ImageIO.read(new File("C:\\Users\\alden\\Desktop\\workspace-JAVA\\BackpackHero\\src\\img\\heroIcon.png"));
		} catch (IOException e) {
		    throw new RuntimeException(e);
		}
		
		while (true) {
			var event = context.pollOrWaitEvent(10);
			if (event != null) {
				var action = event.getAction();
				if (action == Action.KEY_PRESSED && event.getKey() == KeyboardKey.Q) {
					context.exit(0);
				}
				if (action == Action.POINTER_DOWN) {
					var location = event.getLocation();
					Point pt1 =  data.clickOnCell(view.columnFromX(location.x), view.lineFromY(location.y), view);
					SimpleGameView.draw(context, data, view);
					context.renderFrame(graphics -> view.drawImage(graphics, pt1.x(), pt1.y(), 75, 75, image));
				}
			}
		}
		
	}
	
	public static void main(String[] args) {
		Application.run(new Color(185, 122, 87), SimpleGameController::mapGenerator);
	}
}
